#include "stack.h"
#include <stdlib.h>
#include <stdio.h>

engr120_stack_t init() {
}

void show(engr120_stack_t s) {
}

int pop(engr120_stack_t *s) {
}

void push(engr120_stack_t *s, int c) {
}

int is_empty(engr120_stack_t s) {
}
